import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { ThemeProvider, createTheme, CssBaseline } from '@mui/material';
import LandingPage from './components/LandingPage';
import ChatRoom from './components/ChatRoom';

const theme = createTheme({
  palette: {
    mode: 'light',
    background: {
      default: '#ebeef4',
      paper: '#ffffff',
    },
    primary: {
      main: '#6689bc',
    },
    secondary: {
      main: '#666666',
    },
    text: {
      primary: '#000000',
      secondary: '#555555',
    }
  },
  typography: {
    fontFamily: '"Tahoma", "Helvetica Neue", Arial, sans-serif',
  },
  components: {
    MuiCssBaseline: {
      styleOverrides: {
        body: {
          overscrollBehavior: 'none',
          '&::-webkit-scrollbar': {
            width: '16px',
          },
          '&::-webkit-scrollbar-track': {
            background: '#f0f0f0',
            border: '1px solid #d4d4d4',
          },
          '&::-webkit-scrollbar-thumb': {
            background: 'linear-gradient(to right, #c1d5f0 0%, #a5bedc 100%)',
            border: '1px solid #7b9ebd',
            borderRadius: '0',
          },
          '&::-webkit-scrollbar-thumb:hover': {
            background: 'linear-gradient(to right, #d7e5f7 0%, #bfd2e8 100%)',
          },
        },
      },
    },
  },
});

function App() {
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Router>
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="/room/:roomId" element={<ChatRoom />} />
        </Routes>
      </Router>
    </ThemeProvider>
  );
}

export default App;
