import React, { useState } from 'react';
import {
  Box,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Typography,
  IconButton,
  Tooltip,
  Tabs,
  Tab,
  Card,
  CardMedia,
  CardActionArea,
  Grid,
  InputAdornment,
} from '@mui/material';
import SettingsIcon from '@mui/icons-material/Settings';
import FormatPaintIcon from '@mui/icons-material/FormatPaint';
import MouseIcon from '@mui/icons-material/Mouse';
import CloseIcon from '@mui/icons-material/Close';
import LinkIcon from '@mui/icons-material/Link';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';

// Example space backgrounds and cursors for quick selection
const backgroundOptions = [
  { name: 'Space', url: 'https://images.unsplash.com/photo-1534796636912-3b95b3ab5986' },
  { name: 'Galaxy', url: 'https://images.unsplash.com/photo-1462331940025-496dfbfc7564' },
  { name: 'Nebula', url: 'https://images.unsplash.com/photo-1543722530-d2c3201371e7' },
  { name: 'Stars', url: 'https://images.unsplash.com/photo-1419242902214-272b3f66ee7a' },
  { name: 'Aurora', url: 'https://images.unsplash.com/photo-1483086431886-3590a88317fe' },
  { name: 'Dark', url: 'https://images.unsplash.com/photo-1572439246916-c7cb7fac6094' }
];

const cursorOptions = [
  { name: 'Rocket', url: 'https://cdn.custom-cursor.com/db/pointer/32/Rocket_Pointer.png' },
  { name: 'UFO', url: 'https://cdn.custom-cursor.com/db/pointer/32/UFO_Pointer.png' },
  { name: 'Planet', url: 'https://cdn.custom-cursor.com/db/pointer/32/Planet_Pointer.png' },
  { name: 'Star', url: 'https://cdn.custom-cursor.com/db/pointer/32/Star_Pointer.png' },
  { name: 'Moon', url: 'https://cdn.custom-cursor.com/db/pointer/32/Moon_Pointer.png' },
  { name: 'Alien', url: 'https://cdn.custom-cursor.com/db/pointer/32/Alien_Pointer.png' }
];

function RoomCustomizationPanel({ roomId, socket, isRoomOwner }) {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [customBackgroundUrl, setCustomBackgroundUrl] = useState('');
  const [customCursorUrl, setCustomCursorUrl] = useState('');
  const [selectedBackground, setSelectedBackground] = useState('');
  const [selectedCursor, setSelectedCursor] = useState('');
  const [activeTab, setActiveTab] = useState(0);
  const [previewBackground, setPreviewBackground] = useState('');
  const [previewCursor, setPreviewCursor] = useState('');
  
  const handleOpenDialog = () => {
    setDialogOpen(true);
    setCustomBackgroundUrl('');
    setCustomCursorUrl('');
    setSelectedBackground('');
    setSelectedCursor('');
    setActiveTab(0);
    
    // Set preview to current room settings
    if (socket) {
      socket.emit('get_room_data', roomId);
    }
  };
  
  const handleCloseDialog = () => {
    setDialogOpen(false);
  };
  
  const handleTabChange = (event, newValue) => {
    setActiveTab(newValue);
  };
  
  const handleBackgroundSelect = (url) => {
    setSelectedBackground(url);
    setCustomBackgroundUrl('');
    setPreviewBackground(url);
  };
  
  const handleCursorSelect = (url) => {
    setSelectedCursor(url);
    setCustomCursorUrl('');
    setPreviewCursor(url);
  };
  
  const handleCustomBackgroundChange = (e) => {
    setCustomBackgroundUrl(e.target.value);
    setSelectedBackground('');
    if (e.target.value) {
      setPreviewBackground(e.target.value);
    }
  };
  
  const handleCustomCursorChange = (e) => {
    setCustomCursorUrl(e.target.value);
    setSelectedCursor('');
    if (e.target.value) {
      setPreviewCursor(e.target.value);
    }
  };
  
  const handleSaveCustomization = () => {
    // Background customization
    const backgroundUrl = selectedBackground || customBackgroundUrl;
    
    // Cursor customization
    const cursorUrl = selectedCursor || customCursorUrl;
    
    if (backgroundUrl || cursorUrl) {
      socket.emit('update_room_customization', { 
        roomId, 
        backgroundUrl, 
        cursorUrl 
      });
    }
    
    handleCloseDialog();
  };
  
  const handlePreviewCustom = (type) => {
    if (type === 'background' && customBackgroundUrl) {
      setPreviewBackground(customBackgroundUrl);
    } else if (type === 'cursor' && customCursorUrl) {
      setPreviewCursor(customCursorUrl);
    }
  };
  
  // Listen for room data to initialize previews
  React.useEffect(() => {
    if (socket) {
      const handleRoomData = (roomData) => {
        if (roomData.customization?.backgroundUrl) {
          setPreviewBackground(roomData.customization.backgroundUrl);
        }
        if (roomData.customization?.cursorUrl) {
          setPreviewCursor(roomData.customization.cursorUrl);
        }
      };
      
      socket.on('room_data', handleRoomData);
      
      return () => {
        socket.off('room_data', handleRoomData);
      };
    }
  }, [socket]);
  
  if (!isRoomOwner) return null;
  
  return (
    <>
      <Tooltip title="Customize Room">
        <IconButton 
          onClick={handleOpenDialog}
          sx={{ 
            color: '#fff',
            borderRadius: '50%',
            backgroundColor: 'rgba(30, 30, 30, 0.5)',
            '&:hover': {
              backgroundColor: 'rgba(60, 60, 60, 0.5)'
            },
            padding: '6px',
            marginLeft: 1
          }}
        >
          <SettingsIcon fontSize="small" />
        </IconButton>
      </Tooltip>
      
      <Dialog 
        open={dialogOpen} 
        onClose={handleCloseDialog}
        maxWidth="md"
        fullWidth
        PaperProps={{
          sx: {
            backgroundColor: 'rgba(22, 22, 22, 0.95)',
            color: '#fff',
            borderRadius: '12px',
            backdropFilter: 'blur(8px)',
            overflow: 'hidden'
          }
        }}
      >
        <DialogTitle sx={{ 
          display: 'flex', 
          justifyContent: 'space-between', 
          alignItems: 'center',
          backgroundColor: 'rgba(0, 0, 0, 0.3)',
          px: 3, py: 2
        }}>
          <Typography variant="h6" sx={{ fontWeight: 500 }}>
            Room Customization
          </Typography>
          <IconButton edge="end" color="inherit" onClick={handleCloseDialog} aria-label="close">
            <CloseIcon />
          </IconButton>
        </DialogTitle>
        
        {/* Preview area */}
        <Box sx={{ 
          height: '150px', 
          width: '100%',
          backgroundImage: previewBackground ? `url(${previewBackground})` : 'none',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          borderBottom: '1px solid rgba(255,255,255,0.1)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          position: 'relative',
          backgroundColor: previewBackground ? 'transparent' : 'rgba(0,0,0,0.4)'
        }}>
          <Typography 
            variant="h5" 
            sx={{ 
              color: '#fff', 
              textShadow: '0 0 10px rgba(0,0,0,0.8)',
              cursor: previewCursor ? `url(${previewCursor}), auto` : 'default',
              padding: '10px 20px',
              borderRadius: '4px',
              backdropFilter: 'blur(4px)',
              backgroundColor: 'rgba(0,0,0,0.4)'
            }}
          >
            Room Preview
          </Typography>
          
          <Box sx={{ 
            position: 'absolute', 
            bottom: 8, 
            right: 8, 
            backgroundColor: 'rgba(0,0,0,0.6)',
            padding: '4px 8px',
            borderRadius: '4px',
            fontSize: '12px'
          }}>
            {previewBackground ? 'Custom background applied' : 'No background'} • 
            {previewCursor ? 'Custom cursor applied' : 'Default cursor'}
          </Box>
        </Box>
        
        <Box sx={{ borderBottom: 1, borderColor: 'divider', backgroundColor: 'rgba(0, 0, 0, 0.2)' }}>
          <Tabs 
            value={activeTab} 
            onChange={handleTabChange}
            variant="fullWidth"
            textColor="inherit"
            sx={{
              '& .MuiTabs-indicator': {
                backgroundColor: '#1976d2',
              },
              '& .MuiTab-root': {
                color: 'rgba(255,255,255,0.7)',
                '&.Mui-selected': {
                  color: '#fff',
                }
              }
            }}
          >
            <Tab 
              icon={<FormatPaintIcon />} 
              label="Background" 
              sx={{ py: 2 }}
            />
            <Tab 
              icon={<MouseIcon />} 
              label="Cursor" 
              sx={{ py: 2 }}
            />
          </Tabs>
        </Box>
        
        <DialogContent dividers sx={{ p: 3, backgroundColor: 'rgba(15, 15, 15, 0.9)' }}>
          {/* Background Tab */}
          {activeTab === 0 && (
            <Box>
              <Typography variant="subtitle1" gutterBottom>
                Choose a Background
              </Typography>
              
              <Grid container spacing={2} sx={{ mb: 3 }}>
                {backgroundOptions.map((option) => (
                  <Grid item xs={4} sm={4} md={4} key={option.name}>
                    <Card 
                      sx={{ 
                        position: 'relative',
                        borderRadius: '8px',
                        overflow: 'hidden',
                        border: selectedBackground === option.url ? '2px solid #1976d2' : '2px solid transparent',
                        transition: 'all 0.2s ease-in-out',
                        '&:hover': {
                          transform: 'translateY(-4px)',
                          boxShadow: '0 10px 20px rgba(0,0,0,0.4)'
                        }
                      }}
                    >
                      <CardActionArea onClick={() => handleBackgroundSelect(option.url)}>
                        <CardMedia
                          component="img"
                          height="100"
                          image={option.url}
                          alt={option.name}
                        />
                        <Box sx={{ 
                          position: 'absolute',
                          bottom: 0,
                          width: '100%',
                          backgroundColor: 'rgba(0,0,0,0.6)',
                          padding: '6px',
                          display: 'flex',
                          justifyContent: 'space-between',
                          alignItems: 'center'
                        }}>
                          <Typography variant="caption" color="white">
                            {option.name}
                          </Typography>
                          {selectedBackground === option.url && (
                            <CheckCircleIcon sx={{ color: '#1976d2', fontSize: '16px' }} />
                          )}
                        </Box>
                      </CardActionArea>
                    </Card>
                  </Grid>
                ))}
              </Grid>
              
              <Typography variant="subtitle1" gutterBottom>
                Or Use Custom Background URL
              </Typography>
              
              <Box sx={{ display: 'flex', gap: 1, mt: 1 }}>
                <TextField
                  fullWidth
                  placeholder="https://example.com/your-background.jpg"
                  value={customBackgroundUrl}
                  onChange={handleCustomBackgroundChange}
                  variant="outlined"
                  size="small"
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">
                        <LinkIcon sx={{ color: 'rgba(255,255,255,0.5)' }} />
                      </InputAdornment>
                    ),
                  }}
                  sx={{
                    '& .MuiOutlinedInput-root': {
                      color: 'white',
                      '& fieldset': { borderColor: 'rgba(255,255,255,0.2)' },
                      '&:hover fieldset': { borderColor: 'rgba(255,255,255,0.3)' },
                      '&.Mui-focused fieldset': { borderColor: 'rgba(255,255,255,0.5)' }
                    }
                  }}
                />
                <Button 
                  variant="outlined" 
                  onClick={() => handlePreviewCustom('background')}
                  disabled={!customBackgroundUrl}
                >
                  Preview
                </Button>
              </Box>
            </Box>
          )}
          
          {/* Cursor Tab */}
          {activeTab === 1 && (
            <Box>
              <Typography variant="subtitle1" gutterBottom>
                Choose a Cursor
              </Typography>
              
              <Grid container spacing={2} sx={{ mb: 3 }}>
                {cursorOptions.map((option) => (
                  <Grid item xs={4} sm={4} md={2} key={option.name}>
                    <Card 
                      sx={{ 
                        position: 'relative',
                        borderRadius: '8px',
                        overflow: 'hidden',
                        border: selectedCursor === option.url ? '2px solid #1976d2' : '2px solid transparent',
                        transition: 'all 0.2s ease-in-out',
                        backgroundColor: 'rgba(30,30,30,0.6)',
                        '&:hover': {
                          transform: 'translateY(-4px)',
                          boxShadow: '0 10px 20px rgba(0,0,0,0.4)'
                        }
                      }}
                    >
                      <CardActionArea 
                        onClick={() => handleCursorSelect(option.url)}
                        sx={{ 
                          display: 'flex', 
                          flexDirection: 'column',
                          alignItems: 'center',
                          padding: '12px 8px'
                        }}
                      >
                        <Box sx={{ 
                          height: '32px', 
                          width: '32px',
                          display: 'flex',
                          justifyContent: 'center',
                          mb: 1
                        }}>
                          <img 
                            src={option.url} 
                            alt={option.name} 
                            style={{ maxWidth: '100%', maxHeight: '100%' }} 
                          />
                        </Box>
                        <Typography variant="caption" color="white" textAlign="center">
                          {option.name}
                        </Typography>
                        {selectedCursor === option.url && (
                          <CheckCircleIcon sx={{ color: '#1976d2', fontSize: '16px', mt: 0.5 }} />
                        )}
                      </CardActionArea>
                    </Card>
                  </Grid>
                ))}
              </Grid>
              
              <Typography variant="subtitle1" gutterBottom>
                Or Use Custom Cursor URL
              </Typography>
              
              <Box sx={{ display: 'flex', gap: 1, mt: 1 }}>
                <TextField
                  fullWidth
                  placeholder="https://example.com/your-cursor.png"
                  value={customCursorUrl}
                  onChange={handleCustomCursorChange}
                  variant="outlined"
                  size="small"
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">
                        <LinkIcon sx={{ color: 'rgba(255,255,255,0.5)' }} />
                      </InputAdornment>
                    ),
                  }}
                  sx={{
                    '& .MuiOutlinedInput-root': {
                      color: 'white',
                      '& fieldset': { borderColor: 'rgba(255,255,255,0.2)' },
                      '&:hover fieldset': { borderColor: 'rgba(255,255,255,0.3)' },
                      '&.Mui-focused fieldset': { borderColor: 'rgba(255,255,255,0.5)' }
                    }
                  }}
                />
                <Button 
                  variant="outlined" 
                  onClick={() => handlePreviewCustom('cursor')}
                  disabled={!customCursorUrl}
                >
                  Preview
                </Button>
              </Box>
              
              <Typography variant="caption" sx={{ display: 'block', mt: 2, color: 'rgba(255,255,255,0.6)' }}>
                Note: For best results, use transparent PNG files of size 32×32 pixels for cursors.
              </Typography>
            </Box>
          )}
        </DialogContent>
        
        <DialogActions sx={{ p: 2, backgroundColor: 'rgba(0, 0, 0, 0.3)', justifyContent: 'space-between' }}>
          <Button 
            onClick={handleCloseDialog}
            sx={{ 
              color: 'rgba(255,255,255,0.7)',
              '&:hover': {
                backgroundColor: 'rgba(255,255,255,0.05)'
              }
            }}
          >
            Cancel
          </Button>
          <Button 
            onClick={handleSaveCustomization} 
            variant="contained" 
            color="primary"
            disabled={!selectedBackground && !customBackgroundUrl && !selectedCursor && !customCursorUrl}
          >
            Apply Changes
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
}

export default RoomCustomizationPanel; 